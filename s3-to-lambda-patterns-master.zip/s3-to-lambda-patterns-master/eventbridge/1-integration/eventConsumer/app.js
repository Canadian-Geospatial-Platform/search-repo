// The standard Lambda handler

exports.handler = async (event) => {
  console.log(event)
}


